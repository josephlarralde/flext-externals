(cd ~/pd/src; sh ../linux/detab-src.sh)

cd ~/pd
git add INSTALL.txt LICENSE.txt README.txt configure.ac doc extra man \
    portaudio portmidi src tcl msw linux mac
